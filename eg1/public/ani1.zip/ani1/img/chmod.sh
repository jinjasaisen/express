#!/bin/bash

chmod 777 -R cmd/
