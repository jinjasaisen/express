#!/bin/bash

convert \
-size 300x200 \
-font /mnt/data/Font/sazanami-gothic.ttf \
-pointsize 20 \
-background none \
-fill white \
label:"営業で飛びまわる\nあにきをさがしてタップ!\n
あにきは10点\n時々あらわれる、\nスーパーあにきは100点!" \
lab1.png
