#!/bin/bash

mogrify -fuzz 25% \
-transparent white $1 
