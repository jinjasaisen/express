#!/bin/bash

convert \
-size 300x200 \
-font /mnt/data/Font/sazanami-gothic.ttf \
-pointsize 36 \
-background none \
-fill blue \
-undercolor lightblue \
label:"あにきをさがせ!" \
lab2.png
