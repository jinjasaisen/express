#!/bin/bash

convert $1 -rotate "+90>" 2$1
