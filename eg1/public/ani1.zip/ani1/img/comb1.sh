#!/bin/bash

convert +append $1 $2 $3
